Improve classifier predictions for sequential data with Hidden Markov Models (HMMs).
The online documentation is accessible at `<https://github.com/minodes/hmm_filter>`_.